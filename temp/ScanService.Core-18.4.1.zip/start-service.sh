#!/bin/bash

dotnet ScanService.Core.dll --url "http://*:5000"